package kr.co.group.pay;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import kr.co.group.admin.AdminDAO;

@RequestMapping("pay")
@Controller
public class PayCont {
	
	@Autowired
	private AdminDAO adao;
	
	@Autowired
	private PayDAO pdao;
	
	public PayCont() {
		System.out.println("-----PayCont() 객체 생성함");
	} // 생성자 ends
	
	@GetMapping("/home")
	public ModelAndView home(HttpServletRequest req) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/pay/home");
		
		String[] sin_codes = req.getParameterValues("sin_code");
		
		List<PayDTO> list = pdao.order("20230910-132628");
		System.out.println(list);
		
		int totalRowCount = pdao.totalRowCount();
		
		mav.addObject("list", list);
		mav.addObject("count", totalRowCount);
		return mav;
	} // home() ends 
	
	
	
} // class ends

